# CoinPade

<p>Bot untuk Nuyul Aplikasi CoinPade</p>

### Cara Install

<pre><code>apt update && apt upgrade
pkg install git
pkg install python
pip install --upgrade pip
pip install requests
git clone https://github.com/kadal15/CoinPade.git
cd CoinPade
pkg install nano
nano config.json
python bot.py</code></pre>

### Edit Config.php

<p>Isi Dengan Data Milik Anda</p>

<pre><code>{
      "androidDeviceToken": "xxxxxxxxxxxxxxxxxxxxx",
      "api_token": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
      "device_id": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
}</code></pre>

### Kunjungi Juga

<p>Blog Jejaka Tutorial : https://jejakatutorial-termux.blogspot.com</p>

<p>Channel Youtube : https://www.youtube.com/channel/UCn5d8Xbp0yt-SWTmxwtayvQ</p>

### Donation

<p>BTC  : 18961sqv9fPuBcEbbi1gHub8ydWePB8yaG</p>

<p>LTC  : LNRkk6o9h1Rh98sDW8byeH9HbeUHwNohDu</p>

<p>ETH  : 0x918af3ccc0012292077891e925668499ee02cdcb</p>

<p>DOGE : DJG4YG3ARUkSt9e5xvHvSS3faVx3v1HM9p</p>
